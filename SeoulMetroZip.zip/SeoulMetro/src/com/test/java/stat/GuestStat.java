package com.test.java.stat;

public class GuestStat {

	public static int[] cal(String lines) {
		
		return CongestionStat.TotalCal(lines);
		
		// 달 별로 파일 가져와서 > 계산 > 출력
		
		//1 파일 가져오기
		
	}

}
